
# print(json_str)

def parse_single_level_json(json_str):
    print(json_str)
    json_to_dict={}
    start_index=0    
    open_brace=str(json_str).find('{',start_index)
    colon_search=0
    while colon_search >= 0:
        colon_search=str(json_str).find(':',open_brace+1)
        key=json_str[open_brace+1:colon_search]
        if json_str[colon_search+1]=='"':
            comma_search=str(json_str).find('",',colon_search)+1
        elif json_str[colon_search+1]=="'":
            comma_search=str(json_str).find("',",colon_search)+1
        else:
            comma_search=str(json_str).find(',',colon_search+1)
        if comma_search== -1:
            comma_search=str(json_str).find('}',colon_search+1)        
        value=json_str[colon_search+1:comma_search]
        print(key,":",value)  
        json_to_dict[key]=value.replace('"','').replace("'","")
        open_brace=comma_search
        print(comma_search)
        if json_str[comma_search]=='}':
            break
    return json_to_dict


def parse_nested_json(json_str1):
    open_brace_pos=[]
    end_brace_pos=[]

    for js1i in range(0,len(json_str1)):
        if json_str1[js1i]=='{':
            open_brace_pos.append(js1i)
        elif json_str1[js1i]=='}':
            end_brace_pos.append(js1i)

    open_brace_pos.reverse()

    processed_elements=[]
    final_dict={}
    for obpi in range(0,len(open_brace_pos)):
        sub_json=(json_str1[open_brace_pos[obpi]:end_brace_pos[obpi]+1])
        for pei in processed_elements:
            sub_json=sub_json.replace(pei,'')
        # print(sub_json)
        if open_brace_pos[obpi] > 0:
            sub_json_key_str=json_str1[0:open_brace_pos[obpi]]              
            comma_search=sub_json_key_str.rfind(',')
            sub_json_key_str=sub_json_key_str[comma_search:]
            processed_elements.append(sub_json_key_str)
            processed_elements.append(sub_json)
            colon_search=sub_json_key_str.find(':',0)
            key=sub_json_key_str[1:colon_search]
            # print(key)
            value=parse_single_level_json(sub_json)
            for vi in value:
                print('----')
                print(vi)
                print(key)
                key_derived='"'+((key+"_"+vi).replace('"','').replace('"',''))+'"'
                print(key_derived)
                print('----')
                final_dict[key_derived.replace('"','')]=value[vi]
        else:
            value=parse_single_level_json(sub_json)
            for vi in value:
                final_dict[vi.replace('"','')]=value[vi]
    print('--------------')
    print(final_dict)
    return final_dict

def parse_json_lst(json_str1):
    
    json_str1_bckup=json_str1
    # for obpi in range(0,len(open_brace_pos)):
    while True:
        obpi=0
        open_brace_pos=[]
        end_brace_pos=[]

        for js1i in range(0,len(json_str1)):
            if json_str1[js1i]=='[':
                open_brace_pos.append(js1i)
            elif json_str1[js1i]==']':
                end_brace_pos.append(js1i)
        
        if len(open_brace_pos) <=0:
            return json_str1

        open_brace_pos.reverse()
        sub_json=(json_str1[open_brace_pos[obpi]:end_brace_pos[obpi]+1])
        json_array_vals=[]
        print(sub_json)        
        if '{' == sub_json[1]:            
            colon_search=sub_json.find(':',0)
            starting_chars_inner_json=sub_json[1:colon_search]
            print(starting_chars_inner_json)            
            strt_indx=1
            while True:
                
                end_indx=sub_json.find(starting_chars_inner_json,strt_indx+2)
                print(end_indx)
                return
                if end_indx == -1:
                    end_indx=sub_json.find(']',strt_indx)+1
                print(end_indx)
                print(sub_json[end_indx-1])
                inner_json=sub_json[strt_indx:end_indx-1]
                val=parse_nested_json(inner_json)
                json_array_vals.append(val)
                strt_indx=end_indx
                if sub_json[end_indx-1]==']':
                    break
        elif sub_json[1]=='"':
            starting_chars_inner_json='","'
            strt_indx=1
            while True:
                end_indx=sub_json.find(starting_chars_inner_json,strt_indx)
                if end_indx== -1:
                    end_indx=sub_json.find(']',strt_indx)-1
                inner_json=sub_json[strt_indx:end_indx+1]
                val=(inner_json)
                json_array_vals.append(val)
                strt_indx=end_indx
                if sub_json[end_indx+1]==']':
                    break
        elif sub_json[1]=="'":
            starting_chars_inner_json="','"
            strt_indx=1
            while True:
                end_indx=sub_json.find(starting_chars_inner_json,strt_indx)
                if end_indx== -1:
                    end_indx=sub_json.find(']',strt_indx)-1
                inner_json=sub_json[strt_indx:end_indx+1]
                val=(inner_json)
                json_array_vals.append(val)
                strt_indx=end_indx
                if sub_json[end_indx+1]==']':
                    break
        else:
            sub_json=sub_json[1:len(sub_json)]
            json_array_vals=sub_json.split(',')       
            
        
        sub_json_key_str=json_str1[0:open_brace_pos[obpi]]              
        sub_json_key_str_bckup=sub_json_key_str
        comma_search=sub_json_key_str.rfind(',')
        sub_json_key_str=sub_json_key_str[comma_search:]
        colon_search=sub_json_key_str.find(':',0)
        key=sub_json_key_str[1:colon_search]
        sub_json_str_comma_search=sub_json_key_str_bckup.rfind(',')
        sub_json_key_str_bckup=sub_json_key_str_bckup[0:sub_json_str_comma_search+1]
        rev_json_array_vals=""
        for jsvi in json_array_vals:
            rev_json_array_vals=rev_json_array_vals+","+str(key)+":"+str(jsvi)
        

        json_str1=sub_json_key_str_bckup+rev_json_array_vals[1:]+json_str1[end_brace_pos[obpi]:]
        # return rev_json_str

def main():
    fp=open(r'C:\Users\asrilekh\Desktop\test_nest_json.json','r')
    rl=fp.readlines()
    # print(rl)
    rls=[]
    for rli in rl:
        s1=str(rli).replace('\n','').replace('"{','{').replace('}"','}').replace('\"','"').replace("\t",'').replace('  ',' ')
        for ci in ['{','}','[',']',',','"',"'",":"]:
            s1=s1.replace(' '+ci,ci).replace(ci+' ',ci)    
        rls.append(s1)
    raw_json_ext=''.join(rls)
    print(raw_json_ext.replace('\n','').replace('"{','{').replace('}"','}').replace('\\"','"').replace("\t",'').replace('  ',' '))
    op1=parse_json_lst(raw_json_ext)
    print(op1)
    op2=parse_nested_json(op1) 

main()   
