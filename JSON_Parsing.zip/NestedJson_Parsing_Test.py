###########--------- Worked code

# import json
# from pprint import pprint
# from pandas.io.json import json_normalize

# with open(r'C:\Users\asrilekh\Desktop\test_nest_json.json') as f:
#     data=json.load(f)
#     # pprint(data)
#     df=json_normalize(data)
#     print(df)
#     df.to_csv(r'C:\Users\asrilekh\Desktop\test_nest_json.csv',index=False)

###########--------- Worked code

import json
from pprint import pprint
from pandas.io.json import json_normalize

with open(r'C:\Users\asrilekh\Desktop\test_nest_json.json') as f:
    data=json.load(f)

def flatten_json(y):
    out={}
    def flatten(x,name=''):
        if type(x) is dict:
            for a in x:
                    flatten(x[a],name+a+"_")
        elif type(x) is list:
            i=0
            for a in x:
                flatten(a,name+str(i)+"_")
                i +=1
        else:
            out[name[:-1]]=x
    flatten(y)
    return out

flat=flatten_json(data)
# pprint(data)
df=json_normalize(flat)
print(df)
df.to_csv(r'C:\Users\asrilekh\Desktop\test_nest_json.csv',index=False)